package com.test.rupeek.firstRound.modals;

public class UserDetails {

	public static String expectedResult = "[\n" + "    {\n" + "        \"first_name\": \"Aliko\",\n"
			+ "        \"last_name\": \"Dangote\",\n" + "        \"career\": \"Billionaire Industrialist\",\n"
			+ "        \"phone\": \"8037602400\"\n" + "    },\n" + "    {\n" + "        \"first_name\": \"Bill\",\n"
			+ "        \"last_name\": \"Gates\",\n" + "        \"career\": \"Billionaire Tech Entrepreneur\",\n"
			+ "        \"phone\": \"9972939567\"\n" + "    },\n" + "    {\n"
			+ "        \"first_name\": \"Folrunsho\",\n" + "        \"last_name\": \"Alakija\",\n"
			+ "        \"career\": \"Billionaire Oil Magnate\",\n" + "        \"phone\": \"9995879555\"\n" + "    }\n"
			+ "]";

}
